# Quesiton 1 Lab: Loops
# Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

SEPERATOR_DASH = "-"
SEPAROTOR_SPACE = " "
SEPAROTOR_APOS = "'"
MIN_NAME_LEN = 3
MIN_PIN_LEN = 6

NAME_ISNOT_VALID = "Your first name must contain only alphabetic characters."
NAME_ISNOT_LONG = "Your first name does not contain enough alphabetic characters."
PIN_ISNOT_VALID = "Digits only in the pin number please."
INVALID_PINLEN= f"The pin number must be {MIN_PIN_LEN} consecutive digits in length."

invalid_name = True
invalid_pin = True

# Name Validity Check
while invalid_name:
    first_name = input("Please enter your first name: ").strip().title()
    
    #replace seperators to validate name properly  
    seperator_name = first_name.replace(SEPERATOR_DASH, "").replace(SEPAROTOR_SPACE, "").replace(SEPAROTOR_APOS,"")
##    print(f"This is the string you are comparing {seperator_name}")
    if not (seperator_name.isalpha()):
        print(NAME_ISNOT_VALID)
##        print("name failed")
    if not len(seperator_name) >= MIN_NAME_LEN:
##        print("name len failed")
        print(NAME_ISNOT_LONG)
    elif seperator_name.isalpha():
        invalid_name = False

# Pin number Validity Check 
while invalid_pin:
    pin_number = input("Please enter your pin number: ").strip()
    if not pin_number.isdigit():
        print(PIN_ISNOT_VALID)
    if len(pin_number) != MIN_PIN_LEN:
        print(INVALID_PINLEN)
    elif pin_number.isdigit():
        invalid_pin = False

# Output
print(f"Your pin number has been confirmed {first_name}, thank you.")
        

        
