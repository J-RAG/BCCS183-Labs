# Quesiton 1 Lab: Lists
# Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

EMPTY_LIST = "Sorry, the list is empty."

def display_as_list(display_items, message="Item", counter_reqd=True):
    """
        Displays Items in a List-format.
    """
    if len(display_items) == 0:
        print(EMPTY_LIST)
        return False
    else:
        print()
        for index, item in enumerate(display_items, start = 1):
            print(f"{message} {index}: {item}" if counter_reqd else item)
        return True
