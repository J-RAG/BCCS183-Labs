# Quesiton 2 Lab: Dictionaries
# Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

SEPARATOR = "Gap"

MORSE_LANGUAGE = {
    "A" : ".-", 
    "B" : "-...", 
    "C" : "-.-.", 
    "D" : "-..", 
    "E" : ".", 
    "F" : "..-.", 
    "G" : "--.", 
    "H" : "....", 
    "I" : "..", 
    "J" : ".---", 
    "K" : "-.-", 
    "L" : ".-..", 
    "M" : "--", 
    "N" : "-.", 
    "O" : "---", 
    "P" : ".--.", 
    "Q" : "--.-", 
    "R" : ".-.", 
    "S" : "...", 
    "T" : "-", 
    "U" : "..-", 
    "V" : "...-", 
    "W" : ".--", 
    "X" : "-..-", 
    "Y" : "-.--", 
    "Z" : "--..", 
    "0" : "-----", 
    "1" : ".----", 
    "2" : "..---", 
    "3" : "...--", 
    "4" : "....-", 
    "5" : ".....", 
    "6" : "-....", 
    "7" : "--...", 
    "8" : "---..", 
    "9" : "----.", 
    "." : ".-.-.-", 
    "," : "--..--"
    }

sentence = input("Please enter the phrase to send: ").strip()
position = 0 # start loop
while position < len(sentence):
    # In Morse Dictionary
    if sentence[position].upper() in MORSE_LANGUAGE:
        print(f"{sentence[position]} in morse is {MORSE_LANGUAGE[sentence[position].upper()]}")

    # Not in Morse Dictionary        
    elif sentence[position] != " ": # Skip if the current character is a space
        print(f"{sentence[position]} is not available in morse.")

    # Print "Gap" if it is whitespace         
    elif sentence[position - 1] != " ":
        print(SEPARATOR)
    position += 1
