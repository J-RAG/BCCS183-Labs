# Quesiton 1 Lab 1-1
# Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

YES_RESPONSE = "y"

print("The pizza chooser.")

#User inputs 
vege = input("Are you a vegetarian? ").lower().strip().startswith(YES_RESPONSE)
vegan = input("Are you a vegan? ").lower().strip().startswith(YES_RESPONSE)
meat = input("Are you a meat eater? ").lower().strip().startswith(YES_RESPONSE)
wanttoeat = input("Would you like to eat a pizza? ").lower().strip().startswith(YES_RESPONSE)

#Logic 
vege_resp = (vege and not vegan and wanttoeat) and not (meat) 
vegan_resp = (vegan ^ vege) and not (meat) and (wanttoeat)
meat_resp = (meat and wanttoeat) and not (vege or vegan) 

#Output
print()
print(f"It is {str(vege_resp).lower()} that you would like a veggie pizza.")
print(f"It is {str(vegan_resp).lower()} that you would like a vegan pizza.")
print(f"It is {str(meat_resp).lower()} that you would like a carnivore pizza.")
