# Quesiton 1 Lab 1-3
# Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz


YES_RESP = "y"
NO_MONEY = float(0)
TOO_COLD = "It's not warm enough, stay at home."
BEACH_RESP = "Enjoy your time at the beach."
HOME_RESP = "Ok, enjoy your time at home."
NO_CASH_MSG = "Please remember to bring cash next time."
INSUFFICIENT_FUNDS = "Sorry, no ice cream today."
INVALID_TEMP = "The temperature needs to be a number."


name = input("Please enter your first name: ").strip().title()
goto_beach = input(f"Hi {name}, do you want to go to the beach? (y/n): ").strip().lower()

# Beach response
if not goto_beach.startswith(YES_RESP):
    print(HOME_RESP)
    
else:
    curr_temp = input("Please tell me the current temperature: ").strip()
    
    # Temperature Validity
    if (not curr_temp.isdigit()) and (not curr_temp.count(".") <= 1):
        print(INVALID_TEMP)
        
    else:
        minimum_temp = input("What is the minimum temperature for going to the beach? ").strip()
        if (not minimum_temp.isdigit()) or (not minimum_temp.count(".") <= 1):
            print(INVALID_TEMP)

        elif float(curr_temp) < float(minimum_temp):
            print(TOO_COLD)
        
        else:
            print(f"You can go to the beach because it is {float(curr_temp)} degrees.")
            want_ice_cream = input("Do you want to buy an ice cream? (y/n): ").strip().lower()

            # Ice cream response
            if  want_ice_cream.startswith(YES_RESP):
                balance = input("How much cash do you have? ").strip()

                # Money Check
                if (not balance.isdigit()) and (not balance.count(".") <= 1):
                    print(f"{balance} was not a valid amount of money.")
                elif float(balance) == NO_MONEY:
                    print(NO_CASH_MSG)
                else: 
                    ice_cream_cost = input("How much is an ice cream? ").strip()

                    if (not ice_cream_cost.isdigit()) and (not ice_cream_cost.count(".") <= 1):
                        print(f"{ice_cream_cost} was not a valid amount of money.")

                    elif float(ice_cream_cost) > float(balance):
                        print(INSUFFICIENT_FUNDS)
                        
                    else:
                        change = float(balance) - float(ice_cream_cost)
                        print(f"You can buy an ice cream and you will have ${change:.2f} left.")
                
            print(BEACH_RESP)
