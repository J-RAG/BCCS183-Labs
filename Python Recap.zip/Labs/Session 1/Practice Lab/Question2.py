# Practice Lab Question 1- Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz
CLASS_CODE = "BCCS183"
first_name = input("Please enter your first name: ")
print(f"Hi {first_name}, welcome to {CLASS_CODE}.")
