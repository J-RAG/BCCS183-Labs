# Practice Lab Question 1- Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz
# The line of text you need to use to generate the output is given below for you.
# Do not alter anything inside the quotes.
print("Hi and welcome to BCCS183.")
