# Quesiton 1 Lab 1-2
# Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

EQUAL = "an equilateral" 
SCALENE = "a scalene"
ISO = "an isosceles"
INVALID_INPUT_MSG = "One or more of the sides was not valid."
TRI_INEQUALITY_THRM = "The triangle inequality theorem requires the sum of two sides to be greater than the third."
DECIMAL = "."
MAX_DECIMAL = 1 # if there is more than 1 ".", input is invalid

side_a = input("Enter the length of side 1: ").strip()
side_b = input("Enter the length of side 2: ").strip()
side_c = input("Enter the length of side 3: ").strip()


# Input Validation Check
# Decimal and Number validation 
if not all([side_a.count(DECIMAL) <= MAX_DECIMAL,
            side_b.count(DECIMAL) <= MAX_DECIMAL,
            side_c.count(DECIMAL) <= MAX_DECIMAL]) or not all ([side_a.replace(DECIMAL, "").isdigit(),
                                                                 side_b.replace(DECIMAL, "").isdigit(),
                                                                 side_c.replace(DECIMAL, "").isdigit()]):
    print(INVALID_INPUT_MSG)
else:

    # Triangle Inequality Theorem Validation    
    if not all ([float(side_a) + float(side_b) > float(side_c),
                 float(side_a) + float(side_c) > float(side_b),
                 float(side_b) + float(side_c) > float(side_a)]):
            print(TRI_INEQUALITY_THRM)
                

    else:
        # Create Compare Sides list
        compare_size = [float(side_a) == float(side_b),
                           float(side_a) == float(side_c),
                           float(side_b) == float(side_c)]

        # Output Results
        if all(compare_size):
            print(f"A triangle with sides {float(side_a)}, {float(side_b)} and {float(side_c)} is {EQUAL} triangle.")
        elif not any(compare_size):
            print(f"A triangle with sides {float(side_a)}, {float(side_b)} and {float(side_c)} is {SCALENE} triangle.")
        else:
            print(f"A triangle with sides {float(side_a)}, {float(side_b)} and {float(side_c)} is {ISO} triangle.")
            
    
    
            


            
